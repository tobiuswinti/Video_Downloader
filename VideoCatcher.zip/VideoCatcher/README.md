# VideoCatcher – Android Video-Downloader

Eine native Android-App (Kotlin + Jetpack Compose): eingebauter Browser, der
Video-URLs auf einer geöffneten Seite erkennt, plus Download-Manager mit
Fortschrittsanzeige, Hintergrund-Downloads und paralleler Warteschlange.

## Funktionen

* **Browser-Tab** – URL eingeben, Seite öffnen, Video abspielen. Jeder
  Netzwerk-Request wird mitgelesen (`shouldInterceptRequest`); erkannte
  Medien-URLs erscheinen in einer Liste über der Seite.
* **Erkennung** – direkte Dateien (`.mp4`, `.webm`, `.mkv`, `.mov`, `.m4a` …)
  und HLS-Playlists (`.m3u8`).
* **Downloads-Tab** – Liste aller Downloads mit Fortschrittsbalken, Größe,
  Geschwindigkeit, Status. Pause / Fortsetzen / Abbrechen / Öffnen.
* **Hintergrund** – Foreground-Service mit Notification; Downloads laufen
  weiter, wenn die App minimiert wird. Nach App-Neustart werden unfertige
  Downloads automatisch wieder aufgenommen.
* **Parallel** – bis zu 3 gleichzeitige Downloads (`DownloadService.MAX_PARALLEL`),
  weitere warten in der Queue.
* **Fortsetzen** – direkte Dateien über HTTP-`Range`-Header, HLS über den
  Segment-Index.
* Cookies und User-Agent der WebView werden an den Download-Request
  weitergereicht, damit sitzungsgeschützte Dateien funktionieren.

## Bauen

1. Ordner in Android Studio öffnen (Ladybug oder neuer).
2. Studio legt beim ersten Sync den Gradle-Wrapper an (`gradle-wrapper.jar`
   ist hier nicht enthalten). Alternativ auf der Konsole: `gradle wrapper`.
3. `Run` – minSdk 24, compileSdk 35.

## Struktur

```
detect/VideoSniffer.kt         URL-Klassifikation (mp4 / m3u8 / ignorieren)
download/ProgressiveDownloader Direktdownload mit Range-Resume
download/HlsDownloader         m3u8 parsen, Segmente laden und anhängen
download/DownloadService       Foreground-Service, Semaphore, Job-Verwaltung
data/                          Room-DB, Entity, DAO, Repository
ui/BrowserScreen.kt            WebView + Trefferliste
ui/DownloadsScreen.kt          Fortschritts-UI
```

## Speicherort

`Android/data/com.example.videocatcher/files/Movies/`
(app-spezifisch, daher ohne Speicherberechtigung nutzbar). Wenn die Dateien
in der Galerie auftauchen sollen, nach Abschluss per MediaStore nach
`Movies/` kopieren – das ist bewusst nicht eingebaut, um Resume einfach zu halten.

## Grenzen

* **DRM-geschützte Streams** (Widevine: Netflix, Disney+, Prime Video …) und
  verschlüsselte HLS-Playlists werden nicht unterstützt und sollen es auch
  nicht – der HLS-Parser bricht bei `#EXT-X-KEY` mit Fehlermeldung ab.
* **MPEG-DASH** (`.mpd`) ist nicht implementiert.
* HLS-Ergebnis ist eine `.ts`-Datei. Für sauberes MP4 wäre ein Remux nötig
  (z. B. mobile-ffmpeg als zusätzliche Abhängigkeit, `-c copy`).
* Seiten, die Videos per Blob-URL oder MSE ausliefern, zeigen im Sniffer nur
  die zugrunde liegende Playlist – manchmal gar nichts.

## Rechtliches

Das Tool lädt nur, was der Server ohne Umgehung von Kopierschutz ausliefert.
Ob ein konkretes Video heruntergeladen werden darf, hängt vom Urheberrecht und
den AGB der jeweiligen Seite ab – eigene Uploads, freie Lizenzen und
Material mit Erlaubnis sind unproblematisch, kommerzielle Streamingdienste
in der Regel nicht.
