package com.example.videocatcher.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun byId(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED','RUNNING')")
    suspend fun unfinished(): List<DownloadEntity>

    @Insert
    suspend fun insert(item: DownloadEntity): Long

    @Update
    suspend fun update(item: DownloadEntity)

    @Query("UPDATE downloads SET status = :status, error = :error WHERE id = :id")
    suspend fun setStatus(id: Long, status: String, error: String? = null)

    @Query("UPDATE downloads SET downloadedBytes = :done, totalBytes = :total, speedBps = :speed WHERE id = :id")
    suspend fun setBytes(id: Long, done: Long, total: Long, speed: Long)

    @Query("UPDATE downloads SET segmentsDone = :done, segmentsTotal = :total, downloadedBytes = :bytes, speedBps = :speed WHERE id = :id")
    suspend fun setSegments(id: Long, done: Int, total: Int, bytes: Long, speed: Long)

    @Query("UPDATE downloads SET status = 'RUNNING' WHERE status = 'RUNNING'")
    suspend fun noop()

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)
}
