package com.example.videocatcher.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.videocatcher.data.DownloadRepository
import com.example.videocatcher.data.Status

@Composable
fun AppRoot(repo: DownloadRepository, initialUrl: String?) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val downloads by repo.downloads.collectAsState(initial = emptyList())
    val active = remember(downloads) { downloads.count { it.status == Status.RUNNING || it.status == Status.QUEUED } }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Public, null) },
                    label = { Text("Browser") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Download, null) },
                    label = { Text(if (active > 0) "Downloads ($active)" else "Downloads") }
                )
            }
        }
    ) { padding ->
        when (tab) {
            0 -> BrowserScreen(
                repo = repo,
                initialUrl = initialUrl,
                modifier = Modifier.padding(padding),
                onDownloadStarted = { tab = 1 }
            )
            else -> DownloadsScreen(
                items = downloads,
                repo = repo,
                modifier = Modifier.padding(padding)
            )
        }
    }
}
