package com.example.videocatcher.download

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.example.videocatcher.data.AppDatabase
import com.example.videocatcher.data.DownloadDao
import com.example.videocatcher.data.Kind
import com.example.videocatcher.data.Status
import com.example.videocatcher.util.Notifications
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Foreground-Service: haelt die Downloads am Leben, waehrend die App im
 * Hintergrund ist. Mehrere Downloads laufen parallel, begrenzt durch [MAX_PARALLEL].
 */
class DownloadService : LifecycleService() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_CANCEL = "cancel"
        const val ACTION_RESUME_ALL = "resume_all"
        const val EXTRA_ID = "id"

        const val MAX_PARALLEL = 3

        fun send(ctx: Context, action: String, id: Long = -1L) {
            val i = Intent(ctx, DownloadService::class.java).setAction(action)
            if (id >= 0) i.putExtra(EXTRA_ID, id)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private lateinit var dao: DownloadDao
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val gate = Semaphore(MAX_PARALLEL)
    private val activeCount = AtomicInteger(0)

    override fun onCreate() {
        super.onCreate()
        dao = AppDatabase.get(this).downloadDao()
        Notifications.createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForeground(Notifications.FOREGROUND_ID, Notifications.progress(this, activeCount.get().coerceAtLeast(1), null, "Wird vorbereitet…"))

        val id = intent?.getLongExtra(EXTRA_ID, -1L) ?: -1L
        when (intent?.action) {
            ACTION_START -> if (id >= 0) startJob(id)
            ACTION_PAUSE -> {
                jobs.remove(id)?.cancel()
                lifecycleScope.launch { dao.setStatus(id, Status.PAUSED); maybeStop() }
            }
            ACTION_CANCEL -> {
                jobs.remove(id)?.cancel()
                lifecycleScope.launch {
                    dao.byId(id)?.let { runCatching { File(it.filePath).delete() } }
                    dao.delete(id)
                    maybeStop()
                }
            }
            ACTION_RESUME_ALL -> lifecycleScope.launch {
                dao.unfinished().forEach { startJob(it.id) }
                maybeStop()
            }
        }
        return Service.START_STICKY
    }

    private fun startJob(id: Long) {
        if (jobs.containsKey(id)) return

        val job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                dao.setStatus(id, Status.QUEUED)
                gate.withPermit {
                    val item = dao.byId(id) ?: return@withPermit
                    activeCount.incrementAndGet()
                    dao.setStatus(id, Status.RUNNING)
                    updateForeground("${item.title}")

                    if (item.kind == Kind.HLS) {
                        HlsDownloader.download(item, item.segmentsDone) { done, total, bytes, speed ->
                            dao.setSegments(id, done, total, bytes, speed)
                            updateForeground(item.title, if (total > 0) done * 100 / total else null)
                        }
                    } else {
                        ProgressiveDownloader.download(item) { done, total, speed ->
                            dao.setBytes(id, done, total, speed)
                            updateForeground(item.title, if (total > 0) (done * 100 / total).toInt() else null)
                        }
                    }

                    dao.setStatus(id, Status.DONE)
                    Notifications.finished(this@DownloadService, id, item.title, true, item.fileName)
                }
            } catch (ce: CancellationException) {
                throw ce                              // Pause/Abbruch: Status wurde schon gesetzt
            } catch (t: Throwable) {
                dao.setStatus(id, Status.ERROR, t.message ?: t.javaClass.simpleName)
                val title = dao.byId(id)?.title ?: "Download"
                Notifications.finished(this@DownloadService, id, title, false, t.message)
            } finally {
                activeCount.decrementAndGet()
                jobs.remove(id)
                maybeStop()
            }
        }
        jobs[id] = job
    }

    private fun updateForeground(text: String, percent: Int? = null) {
        val n = Notifications.progress(this, activeCount.get().coerceAtLeast(1), percent, text)
        try {
            startForeground(Notifications.FOREGROUND_ID, n)
        } catch (_: Exception) { }
    }

    private fun maybeStop() {
        if (jobs.isEmpty()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
            stopSelf()
        }
    }

    override fun onDestroy() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        super.onDestroy()
    }
}
