package com.example.videocatcher.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.input.ImeAction
import com.example.videocatcher.data.DownloadRepository
import com.example.videocatcher.data.Kind
import com.example.videocatcher.detect.MediaHit
import com.example.videocatcher.detect.VideoSniffer

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    repo: DownloadRepository,
    initialUrl: String?,
    modifier: Modifier = Modifier,
    onDownloadStarted: () -> Unit
) {
    val context = LocalContext.current
    var addressText by remember { mutableStateOf(initialUrl ?: "") }
    var currentUrl by remember { mutableStateOf(initialUrl ?: "") }
    var pageTitle by remember { mutableStateOf("") }
    var loadProgress by remember { mutableIntStateOf(100) }
    val hits = remember { mutableStateListOf<MediaHit>() }
    var webView by remember { mutableStateOf<WebView?>(null) }

    fun normalize(input: String): String {
        val t = input.trim()
        return when {
            t.isEmpty() -> t
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(' ') || !t.contains('.') -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(t, "UTF-8")
            else -> "https://$t"
        }
    }

    Column(modifier = modifier.fillMaxSize()) {

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { webView?.let { if (it.canGoBack()) it.goBack() } }) {
                Icon(Icons.Default.ArrowBack, "Zurück")
            }
            OutlinedTextField(
                value = addressText,
                onValueChange = { addressText = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Adresse oder Suche") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    val u = normalize(addressText)
                    if (u.isNotEmpty()) { hits.clear(); webView?.loadUrl(u) }
                })
            )
            IconButton(onClick = { webView?.reload() }) {
                Icon(Icons.Default.Refresh, "Neu laden")
            }
        }

        if (loadProgress in 1..99) {
            LinearProgressIndicator(progress = { loadProgress / 100f }, modifier = Modifier.fillMaxWidth())
        }

        if (hits.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Text("${hits.size} Medien gefunden", fontSize = 14.sp)
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 180.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(hits) { hit ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        hit.fileName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        if (hit.kind == Kind.HLS) "HLS-Stream" else "Direkte Datei",
                                        fontSize = 11.sp
                                    )
                                }
                                IconButton(onClick = {
                                    val cookie = CookieManager.getInstance().getCookie(hit.url)
                                        ?: CookieManager.getInstance().getCookie(currentUrl)
                                    repo.enqueue(
                                        hit = hit,
                                        pageUrl = currentUrl,
                                        title = pageTitle.ifBlank { hit.fileName },
                                        userAgent = webView?.settings?.userAgentString,
                                        cookie = cookie
                                    )
                                    onDownloadStarted()
                                }) { Icon(Icons.Default.Download, "Herunterladen") }
                            }
                            Divider()
                        }
                    }
                    TextButton(onClick = { hits.clear() }) { Text("Liste leeren") }
                }
            }
        }

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?, request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val url = request?.url?.toString() ?: return null
                            if (!VideoSniffer.isNoise(url)) {
                                VideoSniffer.classify(url)?.let { hit ->
                                    view?.post {
                                        if (hits.none { it.url == hit.url }) hits.add(hit)
                                    }
                                }
                            }
                            return null   // Request unveraendert durchreichen
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            hits.clear()
                            currentUrl = url ?: ""
                            addressText = url ?: ""
                            loadProgress = 1
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            currentUrl = url ?: ""
                            pageTitle = view?.title ?: ""
                            loadProgress = 100
                        }
                    }

                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            loadProgress = newProgress
                        }
                    }

                    if (!initialUrl.isNullOrBlank()) loadUrl(normalize(initialUrl))
                    webView = this
                }
            }
        )
    }
}
