package com.example.videocatcher.data

import androidx.room.Entity
import androidx.room.PrimaryKey

object Status {
    const val QUEUED = "QUEUED"
    const val RUNNING = "RUNNING"
    const val PAUSED = "PAUSED"
    const val DONE = "DONE"
    const val ERROR = "ERROR"
}

object Kind {
    const val PROGRESSIVE = "PROGRESSIVE"   // direkte Datei (mp4, webm, ...)
    const val HLS = "HLS"                   // m3u8 Segment-Stream
}

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val pageUrl: String? = null,
    val title: String,
    val fileName: String,
    val filePath: String,
    val kind: String,
    val status: String = Status.QUEUED,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val segmentsTotal: Int = 0,
    val segmentsDone: Int = 0,
    val speedBps: Long = 0L,
    val error: String? = null,
    val userAgent: String? = null,
    val referer: String? = null,
    val cookie: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    /** 0f..1f, oder null wenn die Gesamtgroesse unbekannt ist */
    fun progress(): Float? = when {
        status == Status.DONE -> 1f
        kind == Kind.HLS && segmentsTotal > 0 -> segmentsDone.toFloat() / segmentsTotal
        totalBytes > 0 -> (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
        else -> null
    }
}
