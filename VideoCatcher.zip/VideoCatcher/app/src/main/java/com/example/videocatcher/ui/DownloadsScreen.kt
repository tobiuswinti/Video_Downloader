package com.example.videocatcher.ui

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.videocatcher.data.DownloadEntity
import com.example.videocatcher.data.DownloadRepository
import com.example.videocatcher.data.Kind
import com.example.videocatcher.data.Status
import java.io.File
import java.util.Locale

@Composable
fun DownloadsScreen(
    items: List<DownloadEntity>,
    repo: DownloadRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (items.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Noch keine Downloads.\nÖffne im Browser-Tab eine Seite mit Video.", fontSize = 15.sp)
        }
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(items, key = { it.id }) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(
                        item.title,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(item.fileName, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)

                    val p = item.progress()
                    if (item.status != Status.DONE) {
                        if (p != null) {
                            LinearProgressIndicator(
                                progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                            )
                        } else if (item.status == Status.RUNNING) {
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                            )
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(statusLine(item), fontSize = 12.sp, modifier = Modifier.weight(1f))

                        when (item.status) {
                            Status.RUNNING, Status.QUEUED -> IconButton(onClick = { repo.pause(item.id) }) {
                                Icon(Icons.Default.Pause, "Pause")
                            }
                            Status.PAUSED, Status.ERROR -> IconButton(onClick = { repo.resume(item.id) }) {
                                Icon(Icons.Default.PlayArrow, "Fortsetzen")
                            }
                            Status.DONE -> IconButton(onClick = { open(context, item) }) {
                                Icon(Icons.Default.OpenInNew, "Öffnen")
                            }
                        }

                        IconButton(onClick = {
                            if (item.status == Status.DONE) repo.remove(item.id, deleteFile = true)
                            else repo.cancel(item.id)
                        }) { Icon(Icons.Default.Delete, "Löschen") }
                    }

                    item.error?.takeIf { item.status == Status.ERROR }?.let {
                        Text("Fehler: $it", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

private fun statusLine(item: DownloadEntity): String {
    val size = if (item.kind == Kind.HLS && item.segmentsTotal > 0)
        "${item.segmentsDone}/${item.segmentsTotal} Segmente · ${bytes(item.downloadedBytes)}"
    else if (item.totalBytes > 0)
        "${bytes(item.downloadedBytes)} / ${bytes(item.totalBytes)}"
    else bytes(item.downloadedBytes)

    return when (item.status) {
        Status.RUNNING -> "$size · ${bytes(item.speedBps)}/s"
        Status.QUEUED -> "In Warteschlange · $size"
        Status.PAUSED -> "Pausiert · $size"
        Status.DONE -> "Fertig · ${bytes(item.downloadedBytes)}"
        Status.ERROR -> "Fehlgeschlagen · $size"
        else -> size
    }
}

private fun bytes(b: Long): String {
    if (b <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    var value = b.toDouble()
    var i = 0
    while (value >= 1024 && i < units.lastIndex) { value /= 1024; i++ }
    return String.format(Locale.GERMANY, "%.1f %s", value, units[i])
}

private fun open(context: android.content.Context, item: DownloadEntity) {
    val file = File(item.filePath)
    if (!file.exists()) return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, if (item.kind == Kind.HLS) "video/mp2t" else "video/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Öffnen mit"))
}
