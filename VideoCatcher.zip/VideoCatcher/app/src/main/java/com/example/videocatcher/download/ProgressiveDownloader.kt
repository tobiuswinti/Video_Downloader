package com.example.videocatcher.download

import com.example.videocatcher.data.DownloadEntity
import com.example.videocatcher.download.Http.applyHeaders
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Laedt eine direkte Datei. Unterstuetzt Fortsetzen ueber HTTP-Range-Requests:
 * beim Start wird die bereits vorhandene Dateilaenge als Offset angefordert.
 */
object ProgressiveDownloader {

    suspend fun download(
        item: DownloadEntity,
        onProgress: suspend (done: Long, total: Long, speedBps: Long) -> Unit
    ) {
        val file = File(item.filePath)
        file.parentFile?.mkdirs()

        var existing = if (file.exists()) file.length() else 0L

        val request = Request.Builder()
            .url(item.url)
            .applyHeaders(item.userAgent, item.referer, item.cookie)
            .apply { if (existing > 0) header("Range", "bytes=$existing-") }
            .build()

        Http.client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")

            val body = resp.body ?: throw IOException("Leere Antwort")
            var total: Long

            if (existing > 0 && resp.code == 206) {
                total = if (body.contentLength() > 0) existing + body.contentLength() else -1L
            } else {
                // Server ignoriert Range -> von vorne beginnen
                existing = 0L
                file.delete()
                total = body.contentLength().takeIf { it > 0 } ?: -1L
            }

            var done = existing
            var lastTick = System.currentTimeMillis()
            var lastBytes = done
            var lastReport = 0L

            FileOutputStream(file, existing > 0).use { out ->
                body.byteStream().use { input ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()   // Pause/Abbruch = Cancel
                        val read = input.read(buf)
                        if (read <= 0) break
                        out.write(buf, 0, read)
                        done += read

                        val now = System.currentTimeMillis()
                        if (now - lastReport > 500) {
                            val dt = (now - lastTick).coerceAtLeast(1)
                            val speed = (done - lastBytes) * 1000 / dt
                            onProgress(done, total, speed)
                            lastReport = now
                            lastTick = now
                            lastBytes = done
                        }
                    }
                }
                out.flush()
            }
            onProgress(done, if (total > 0) total else done, 0)
        }
    }
}
