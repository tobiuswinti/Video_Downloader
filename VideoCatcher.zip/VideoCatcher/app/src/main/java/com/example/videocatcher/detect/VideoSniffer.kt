package com.example.videocatcher.detect

import com.example.videocatcher.data.Kind

data class MediaHit(
    val url: String,
    val kind: String,
    val fileName: String
)

/**
 * Erkennt Medien-URLs anhand der Endung bzw. bekannter Muster.
 * Wird aus WebViewClient.shouldInterceptRequest heraus aufgerufen.
 */
object VideoSniffer {

    private val progressiveExtensions = listOf(
        ".mp4", ".m4v", ".webm", ".mkv", ".mov", ".flv", ".avi", ".ts", ".mp3", ".m4a", ".aac", ".opus"
    )

    fun classify(rawUrl: String): MediaHit? {
        val path = rawUrl.substringBefore('?').substringBefore('#').lowercase()
        return when {
            path.endsWith(".m3u8") ->
                MediaHit(rawUrl, Kind.HLS, nameFrom(path, "stream").replace(".m3u8", "") + ".ts")

            path.endsWith(".mpd") -> null   // MPEG-DASH wird (noch) nicht unterstuetzt

            progressiveExtensions.any { path.endsWith(it) } ->
                MediaHit(rawUrl, Kind.PROGRESSIVE, nameFrom(path, "video.mp4"))

            path.contains("/videoplayback") ->
                MediaHit(rawUrl, Kind.PROGRESSIVE, "videoplayback.mp4")

            else -> null
        }
    }

    private fun nameFrom(path: String, fallback: String): String {
        val raw = path.substringAfterLast('/')
        val safe = raw.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return if (safe.length in 1..80) safe else fallback
    }

    /** Segment-Requests von HLS-Streams sind uninteressant, nur die Playlist zaehlt. */
    fun isNoise(url: String): Boolean {
        val p = url.substringBefore('?').lowercase()
        return p.endsWith(".ts") && p.contains("seg")
    }
}
