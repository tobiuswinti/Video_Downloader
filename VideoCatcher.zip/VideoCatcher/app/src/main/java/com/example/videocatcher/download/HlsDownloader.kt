package com.example.videocatcher.download

import com.example.videocatcher.data.DownloadEntity
import com.example.videocatcher.download.Http.applyHeaders
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URI

/**
 * Laedt einen HLS-Stream (.m3u8) segmentweise und haengt die Segmente
 * an eine .ts-Datei an. Fortsetzen funktioniert ueber den Segment-Index:
 * bereits geladene Segmente werden beim Wiederaufnehmen uebersprungen.
 *
 * Verschluesselte Streams (#EXT-X-KEY mit METHOD != NONE) werden bewusst
 * nicht verarbeitet.
 */
object HlsDownloader {

    suspend fun download(
        item: DownloadEntity,
        startSegment: Int,
        onProgress: suspend (segDone: Int, segTotal: Int, bytes: Long, speedBps: Long) -> Unit
    ) {
        val mediaPlaylistUrl = resolveMediaPlaylist(item)
        val segments = parseSegments(fetchText(mediaPlaylistUrl, item), mediaPlaylistUrl)
        if (segments.isEmpty()) throw IOException("Keine Segmente in der Playlist gefunden")

        val file = File(item.filePath)
        file.parentFile?.mkdirs()
        if (startSegment == 0 && file.exists()) file.delete()

        var bytes = if (file.exists()) file.length() else 0L
        var lastTick = System.currentTimeMillis()
        var lastBytes = bytes

        FileOutputStream(file, true).use { out ->
            for (index in startSegment until segments.size) {
                currentCoroutineContext().ensureActive()

                val req = Request.Builder()
                    .url(segments[index])
                    .applyHeaders(item.userAgent, item.referer, item.cookie)
                    .build()

                Http.client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("Segment ${index + 1}: HTTP ${resp.code}")
                    val body = resp.body ?: throw IOException("Segment ${index + 1} leer")
                    body.byteStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val read = input.read(buf)
                            if (read <= 0) break
                            out.write(buf, 0, read)
                            bytes += read
                        }
                    }
                }
                out.flush()

                val now = System.currentTimeMillis()
                val dt = (now - lastTick).coerceAtLeast(1)
                val speed = (bytes - lastBytes) * 1000 / dt
                lastTick = now
                lastBytes = bytes
                onProgress(index + 1, segments.size, bytes, speed)
            }
        }
    }

    /** Master-Playlist -> Variante mit der hoechsten Bandbreite auswaehlen. */
    private fun resolveMediaPlaylist(item: DownloadEntity): String {
        val text = fetchText(item.url, item)
        if (!text.contains("#EXT-X-STREAM-INF")) return item.url

        var bestBandwidth = -1L
        var bestUrl: String? = null
        val lines = text.lines()
        for (i in lines.indices) {
            val line = lines[i].trim()
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue
            val bw = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val target = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") } ?: continue
            if (bw > bestBandwidth) {
                bestBandwidth = bw
                bestUrl = absolute(item.url, target.trim())
            }
        }
        return bestUrl ?: item.url
    }

    private fun parseSegments(playlist: String, playlistUrl: String): List<String> {
        if (Regex("#EXT-X-KEY:[^\\n]*METHOD=(?!NONE)").containsMatchIn(playlist)) {
            throw IOException("Verschlüsselter Stream – wird nicht unterstützt")
        }
        return playlist.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { absolute(playlistUrl, it) }
    }

    private fun fetchText(url: String, item: DownloadEntity): String {
        val req = Request.Builder()
            .url(url)
            .applyHeaders(item.userAgent, item.referer, item.cookie)
            .build()
        Http.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Playlist: HTTP ${resp.code}")
            return resp.body?.string() ?: throw IOException("Playlist leer")
        }
    }

    private fun absolute(base: String, ref: String): String =
        try { URI(base).resolve(ref).toString() } catch (_: Exception) { ref }
}
