package com.example.videocatcher.download

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .build()
    }

    fun Request.Builder.applyHeaders(
        userAgent: String?, referer: String?, cookie: String?
    ): Request.Builder {
        userAgent?.takeIf { it.isNotBlank() }?.let { header("User-Agent", it) }
        referer?.takeIf { it.isNotBlank() }?.let { header("Referer", it) }
        cookie?.takeIf { it.isNotBlank() }?.let { header("Cookie", it) }
        header("Accept", "*/*")
        return this
    }
}
