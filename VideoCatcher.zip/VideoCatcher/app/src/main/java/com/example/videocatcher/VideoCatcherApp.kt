package com.example.videocatcher

import android.app.Application
import com.example.videocatcher.data.DownloadRepository
import com.example.videocatcher.download.DownloadService
import com.example.videocatcher.util.Notifications

class VideoCatcherApp : Application() {

    lateinit var repository: DownloadRepository
        private set

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        repository = DownloadRepository(this)
        // Nach einem Neustart der App unterbrochene Downloads wieder aufnehmen
        DownloadService.send(this, DownloadService.ACTION_RESUME_ALL)
    }
}
