package com.example.videocatcher.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.videocatcher.MainActivity
import com.example.videocatcher.R

object Notifications {
    const val CHANNEL_PROGRESS = "downloads_progress"
    const val CHANNEL_DONE = "downloads_done"
    const val FOREGROUND_ID = 1001

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROGRESS, "Laufende Downloads", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DONE, "Abgeschlossene Downloads", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun contentIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun progress(ctx: Context, active: Int, percent: Int?, text: String): Notification =
        NotificationCompat.Builder(ctx, CHANNEL_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (active == 1) "1 Download läuft" else "$active Downloads laufen")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent(ctx))
            .apply {
                if (percent != null) setProgress(100, percent, false)
                else setProgress(0, 0, true)
            }
            .build()

    fun finished(ctx: Context, id: Long, title: String, ok: Boolean, msg: String?) {
        val n = NotificationCompat.Builder(ctx, CHANNEL_DONE)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "Download fertig" else "Download fehlgeschlagen")
            .setContentText(msg ?: title)
            .setAutoCancel(true)
            .setContentIntent(contentIntent(ctx))
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify((2000 + id).toInt(), n)
        } catch (_: SecurityException) { /* Benachrichtigungen nicht erlaubt */ }
    }
}
