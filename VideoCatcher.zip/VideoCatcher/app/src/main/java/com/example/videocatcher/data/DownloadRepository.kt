package com.example.videocatcher.data

import android.content.Context
import android.os.Environment
import com.example.videocatcher.detect.MediaHit
import com.example.videocatcher.download.DownloadService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.io.File

class DownloadRepository(private val appContext: Context) {

    private val dao = AppDatabase.get(appContext).downloadDao()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val downloads: Flow<List<DownloadEntity>> = dao.observeAll()

    private fun targetDir(): File =
        File(appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: appContext.filesDir, "").apply { mkdirs() }

    private fun uniqueFile(name: String): File {
        val dir = targetDir()
        var candidate = File(dir, name)
        var i = 1
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        while (candidate.exists()) {
            candidate = File(dir, if (ext.isEmpty()) "${base}_$i" else "${base}_$i.$ext")
            i++
        }
        return candidate
    }

    fun enqueue(hit: MediaHit, pageUrl: String?, title: String, userAgent: String?, cookie: String?) {
        scope.launch {
            val file = uniqueFile(hit.fileName)
            val entity = DownloadEntity(
                url = hit.url,
                pageUrl = pageUrl,
                title = title.ifBlank { hit.fileName },
                fileName = file.name,
                filePath = file.absolutePath,
                kind = hit.kind,
                status = Status.QUEUED,
                userAgent = userAgent,
                referer = pageUrl,
                cookie = cookie
            )
            val id = dao.insert(entity)
            DownloadService.send(appContext, DownloadService.ACTION_START, id)
        }
    }

    fun pause(id: Long) = DownloadService.send(appContext, DownloadService.ACTION_PAUSE, id)
    fun resume(id: Long) = DownloadService.send(appContext, DownloadService.ACTION_START, id)
    fun cancel(id: Long) = DownloadService.send(appContext, DownloadService.ACTION_CANCEL, id)

    fun remove(id: Long, deleteFile: Boolean) {
        scope.launch {
            dao.byId(id)?.let { if (deleteFile) runCatching { File(it.filePath).delete() } }
            dao.delete(id)
        }
    }
}
